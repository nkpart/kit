void motive();
